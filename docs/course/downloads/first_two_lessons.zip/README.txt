Creative Thinking Course: first two lessons

Use the Python environment where Funground is installed.
Start with: python 01_starter.py, then python 02_starter.py.
Each script saves a PNG in your current folder and opens a window.
Close the window to finish. Files ending in _exercise.py are your assignment starters.
The other scripts show complete visual comparisons.

Source repository: https://github.com/funground-hq/funground
Course pages: docs/course/README.md in that repository.
All sketches are CC0; the accompanying LICENSE gives the terms.
