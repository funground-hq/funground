Creative Thinking Course: first two lessons

Use the Python environment where Funground is installed.
Begin with each lesson's NN_starter.py. The other files are comparison studies.
Scripts save a PNG in your current folder and show the image.
Lesson 9's live sketches respond continuously; close the window to finish.
The optional 09_loop.py GIF exporter needs funground[extras] or ffmpeg.
Files ending in _exercise.py are assignment starters.

Source: https://github.com/funground-hq/funground
Course pages: docs/course/README.md in that repository.
All sketches are CC0; LICENSE gives the terms.
